#pragma once

#define HTTP_SERVER "196.251.70.138"
#define HTTP_PORT 80

#define TFTP_SERVER "196.251.70.138"
