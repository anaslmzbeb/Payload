#pragma once

#include "main.h"

void start_connection(char *, Brute *);
void check_connection(int, int);
void disconnect(Brute *);
